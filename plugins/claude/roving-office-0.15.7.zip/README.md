# The Roving Office — Claude Code plugin

Version 0.15.7. A zero-context observer: it turns your agent's lifecycle, tool,
plan, permission and subagent events into characters walking around a live isometric
office. Nothing here enters the model's context or changes how the agent behaves.

## Install

    /plugin marketplace add https://therovingoffice.com/plugins/claude/marketplace.json
    /plugin install roving-office@roving-office

Then restart the session: hooks are read at session start.

Third-party marketplaces have auto-update disabled by default, so a new version is
picked up by `/plugin marketplace update roving-office` followed by
`/plugin update roving-office@roving-office`.

## Pointing it at an office

Installing the plugin does not tell it which office to feed. The adapter reads
`~/.roving-office/endpoint.json`, or the `AOP_URL` and `AOP_TOKEN` environment
variables. Connecting it to a hosted office is separate work and is not part of this
artifact.

## What it may say about you

Redaction defaults to `metadata`: tool classes, targets and timings, no prompt text
and no file contents. `~/.roving-office/settings.json` raises it deliberately.

## Files

`FILES.json` lists every file here with its size and SHA-256.
